package com.example.livethaitranslator

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val req = 71
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
        }
        layout.addView(TextView(this).apply {
            text = "Live Thai Translator\n\nแปลเสียงอังกฤษเป็นไทยแบบต้นแบบ\nเปิด YouTube ด้วยลำโพง แล้วให้แอปฟังผ่านไมโครโฟน"
            textSize = 18f
            gravity = Gravity.CENTER
        })
        layout.addView(Button(this).apply {
            text = "1) อนุญาตหน้าต่างลอย"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "อนุญาตแล้ว", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(Button(this).apply {
            text = "2) เริ่มแปล (ฟังไมโครโฟน)"
            setOnClickListener { startTranslator() }
        })
        layout.addView(Button(this).apply {
            text = "หยุดแปล"
            setOnClickListener { stopService(Intent(this@MainActivity, TranslateOverlayService::class.java)) }
        })
        setContentView(layout)
    }
    private fun startTranslator() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "กรุณาอนุญาตหน้าต่างลอยก่อน", Toast.LENGTH_LONG).show()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), req)
            return
        }
        startForegroundService(Intent(this, TranslateOverlayService::class.java))
        Toast.makeText(this, "เริ่มแปลแล้ว กลับไปเปิด YouTube ได้", Toast.LENGTH_LONG).show()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == req && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startTranslator()
    }
}
