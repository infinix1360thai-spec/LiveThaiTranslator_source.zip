package com.example.livethaitranslator

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors

class TranslateOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var overlay: TextView? = null
    private var speech: SpeechRecognizer? = null
    private val worker = Executors.newSingleThreadExecutor()
    private var lastText = ""
    private var restarting = false

    override fun onCreate() {
        super.onCreate()
        createNotification()
        showOverlay()
        startListening()
    }
    private fun createNotification() {
        val channel = "live_thai_translator"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(channel, "Live translator", NotificationManager.IMPORTANCE_LOW))
        }
        val n = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channel).setContentTitle("Live Thai Translator")
                .setContentText("กำลังฟังเสียงผ่านไมโครโฟน").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        else Notification.Builder(this).setContentTitle("Live Thai Translator")
            .setContentText("กำลังฟังเสียงผ่านไมโครโฟน").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        startForeground(1, n)
    }
    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = TextView(this).apply {
            text = "Live Thai Translator\nรอเสียงภาษาอังกฤษ..."
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xDD202020.toInt())
            setPadding(18, 14, 18, 14)
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM; y = 60 }
        wm.addView(overlay, params)
    }
    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            update("อุปกรณ์นี้ไม่มีบริการรู้จำเสียงที่รองรับ")
            stopSelf(); return
        }
        speech = SpeechRecognizer.createSpeechRecognizer(this)
        speech?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) { update("กำลังฟังภาษาอังกฤษ...") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { restarting = true }
            override fun onError(error: Int) { restartListening() }
            override fun onResults(results: android.os.Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isNotBlank() && text != lastText) {
                    lastText = text
                    update("EN: $text\nTH: กำลังแปล...")
                    translate(text)
                }
                restartListening()
            }
            override fun onPartialResults(partialResults: android.os.Bundle?) {
                val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isNotBlank()) update("EN: $text\nTH: (กำลังฟัง...)")
            }
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US")
        }
        try { speech?.startListening(intent) } catch (_: Exception) { restartListening() }
    }
    private fun restartListening() {
        if (restarting) return
        restarting = true
        overlay?.postDelayed({
            restarting = false
            try { speech?.cancel(); speech?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }) } catch (_: Exception) {}
        }, 450)
    }
    private fun translate(text: String) {
        worker.execute {
            try {
                val q = URLEncoder.encode(text, "UTF-8")
                val conn = URL("https://api.mymemory.translated.net/get?q=$q&langpair=en%7Cth").openConnection() as HttpURLConnection
                conn.connectTimeout = 8000; conn.readTimeout = 8000
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val thai = JSONObject(body).getJSONObject("responseData").optString("translatedText", "แปลไม่สำเร็จ")
                update("EN: $text\nTH: $thai")
            } catch (_: Exception) { update("EN: $text\nTH: เชื่อมต่อบริการแปลไม่ได้") }
        }
    }
    private fun update(s: String) { overlay?.post { overlay?.text = s } }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onDestroy() {
        try { speech?.destroy() } catch (_: Exception) {}
        try { if (overlay != null) wm.removeView(overlay) } catch (_: Exception) {}
        worker.shutdownNow()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
